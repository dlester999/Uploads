﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents a visitor or rewriter for expression trees.</summary>

    public abstract class ExpressionVisitor
    {
        /// <summary>Initializes a new instance of <see cref="T:ExpressionMath.Expressions.ExpressionVisitor" />.</summary>

        protected ExpressionVisitor()
        {
        }

        

        /// <summary>Dispatches the expression to one of the more specialized visit methods in this class.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>

        public virtual Expression Visit(Expression node)
        {
            if (node != null)
                return node.Accept(this);
            return (Expression)null;
        }

        /// <summary>Dispatches the list of expressions to one of the more specialized visit methods in this class.</summary>
        /// <returns>The modified expression list, if any one of the elements were modified; otherwise, returns the original expression list.</returns>
        /// <param name="nodes">The expressions to visit.</param>

        public ReadOnlyCollection<Expression> Visit(ReadOnlyCollection<Expression> nodes)
        {
            Expression[] list = null;
            int index1 = 0;

            for (int count = nodes.Count; index1 < count; ++index1)
            {
                Expression expression = Visit(nodes[index1]);
                if (list != null)
                {
                    list[index1] = expression;
                }
                else if (expression != nodes[index1])
                {
                    list = new Expression[count];
                    for (int index2 = 0; index2 < index1; ++index2)
                    {
                        list[index2] = nodes[index2];
                    }

                    list[index1] = expression;
                }
            }

            if (list == null)
                return nodes;

            return new ReadOnlyCollection<Expression>(list);
        }

        internal Expression[] VisitArguments(IArgumentProvider nodes)
        {
            Expression[] expressionArray = (Expression[])null;
            int index1 = 0;
            for (int argumentCount = nodes.ArgumentCount; index1 < argumentCount; ++index1)
            {
                Expression node = nodes.GetArgument(index1);
                Expression expression = Visit(node);
                if (expressionArray != null)
                    expressionArray[index1] = expression;
                else if (expression != node)
                {
                    expressionArray = new Expression[argumentCount];
                    for (int index2 = 0; index2 < index1; ++index2)
                        expressionArray[index2] = nodes.GetArgument(index2);
                    expressionArray[index1] = expression;
                }
            }
            return expressionArray;
        }

        /// <summary>Visits all nodes in the collection using a specified element visitor.</summary>
        /// <returns>The modified node list, if any of the elements were modified; otherwise, returns the original node list.</returns>
        /// <param name="nodes">The nodes to visit.</param>
        /// <param name="elementVisitor">A delegate that visits a single element, optionally replacing it with a new element.</param>
        /// <typeparam name="T">The type of the nodes.</typeparam>

        public static ReadOnlyCollection<T> Visit<T>(ReadOnlyCollection<T> nodes, Func<T, T> elementVisitor)
        {
            T[] list = (T[])null;
            int index1 = 0;
            for (int count = nodes.Count; index1 < count; ++index1)
            {
                T obj = elementVisitor(nodes[index1]);
                if (list != null)
                    list[index1] = obj;
                else if ((object)obj != (object)nodes[index1])
                {
                    list = new T[count];
                    for (int index2 = 0; index2 < index1; ++index2)
                        list[index2] = nodes[index2];
                    list[index1] = obj;
                }
            }
            if (list == null)
                return nodes;
            return new ReadOnlyCollection<T>(list);
        }
        

        /// <summary>Visits the children of the <see cref="T:ExpressionMath.Expressions.BinaryExpression" />.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>
        protected internal virtual Expression VisitBinary(BinaryExpression node)
        {
            BinaryExpression before = node;
            Expression left = Visit(node.Left);
            Expression right = Visit(node.Right);
            BinaryExpression after = before.Update(left, conversion, right);
            return ExpressionVisitor.ValidateBinary(before, after);
        }

        internal Expression VisitTernary(TernaryExpression ternaryExpression)
        {
            throw new NotImplementedException();
        }

        /// <summary>Visits the children of the <see cref="T:ExpressionMath.Expressions.BlockExpression" />.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>
        protected internal virtual Expression VisitBlock(BlockExpression node)
        {
            int expressionCount = node.ExpressionCount;
            Expression[] args = (Expression[])null;
            for (int index = 0; index < expressionCount; ++index)
            {
                Expression expression1 = node.GetExpression(index);
                Expression expression2 = Visit(expression1);
                if (expression1 != expression2)
                {
                    if (args == null)
                        args = new Expression[expressionCount];
                    args[index] = expression2;
                }
            }
            ReadOnlyCollection<ParameterExpression> variables = this.VisitAndConvert<ParameterExpression>(node.Variables, "VisitBlock");
            if (variables == node.Variables && args == null)
                return (Expression)node;
            for (int index = 0; index < expressionCount; ++index)
            {
                if (args[index] == null)
                    args[index] = node.GetExpression(index);
            }
            return (Expression)node.Rewrite(variables, args);
        }

        /// <summary>Visits the children of the <see cref="T:ExpressionMath.Expressions.ConditionalExpression" />.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>

        protected internal virtual Expression VisitConditional(ConditionalExpression node)
        {
            return (Expression)node.Update(Visit(node.Test), Visit(node.IfTrue), Visit(node.IfFalse));
        }

        /// <summary>Visits the <see cref="T:ExpressionMath.Expressions.ConstantExpression" />.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>

        protected internal virtual Expression VisitConstant(ConstantExpression node)
        {
            return node;
        }
        

        /// <summary>Visits the <see cref="T:ExpressionMath.Expressions.DefaultExpression" />.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>

        protected internal virtual Expression VisitDefault(DefaultExpression node)
        {
            return node;
        }

        /// <summary>Visits the children of the extension expression.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>

        protected internal virtual Expression VisitExtension(Expression node)
        {
            return node.VisitChildren(this);
        }
        

        /// <summary>Visits the children of the <see cref="T:ExpressionMath.Expressions.LoopExpression" />.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>

        protected internal virtual Expression VisitLoop(LoopExpression node)
        {
            return (Expression)node.Update(this.VisitLabelTarget(node.BreakLabel), this.VisitLabelTarget(node.ContinueLabel), Visit(node.Body));
        }
        
        /// <summary>Visits the children of the <see cref="T:ExpressionMath.Expressions.IndexExpression" />.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>

        protected internal virtual Expression VisitIndex(IndexExpression node)
        {
            Expression instance = Visit(node.Object);
            Expression[] arguments = VisitArguments((IArgumentProvider)node);
            if (instance == node.Object && arguments == null)
                return (Expression)node;
            return node.Rewrite(instance, arguments);
        }
        
        /// <summary>Visits the <see cref="T:ExpressionMath.Expressions.ParameterExpression" />.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>
        protected internal virtual Expression VisitParameter(ParameterExpression node)
        {
            return (Expression)node;
        }
        

        /// <summary>Visits the children of the <see cref="T:ExpressionMath.Expressions.SwitchCase" />.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>
        protected virtual SwitchCase VisitSwitchCase(SwitchCase node)
        {
            return node.Update((IEnumerable<Expression>)Visit(node.TestValues), Visit(node.Body));
        }

        /// <summary>Visits the children of the <see cref="T:ExpressionMath.Expressions.SwitchExpression" />.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>
        protected internal virtual Expression VisitSwitch(SwitchExpression node)
        {
            SwitchExpression before = node;
            Expression switchValue = Visit(node.SwitchValue);
            ReadOnlyCollection<SwitchCase> readOnlyCollection = ExpressionVisitor.Visit<SwitchCase>(node.Cases, new Func<SwitchCase, SwitchCase>(VisitSwitchCase));
            Expression defaultBody = Visit(node.DefaultBody);
            SwitchExpression after = before.Update(switchValue, (IEnumerable<SwitchCase>)readOnlyCollection, defaultBody);
            return (Expression)ExpressionVisitor.ValidateSwitch(before, after);
        }

        /// <summary>Visits the children of the <see cref="T:ExpressionMath.Expressions.CatchBlock" />.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>
        protected virtual CatchBlock VisitCatchBlock(CatchBlock node)
        {
            return node.Update(this.VisitAndConvert<ParameterExpression>(node.Variable, "VisitCatchBlock"), this.Visit(node.Filter), Visit(node.Body));
        }

        /// <summary>Visits the children of the <see cref="T:ExpressionMath.Expressions.TryExpression" />.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>
        protected internal virtual Expression VisitTry(TryExpression node)
        {
            return (Expression)node.Update(Visit(node.Body), (IEnumerable<CatchBlock>)ExpressionVisitor.Visit<CatchBlock>(node.Handlers, new Func<CatchBlock, CatchBlock>(VisitCatchBlock)), Visit(node.Finally), this.Visit(node.Fault));
        }

        /// <summary>Visits the children of the <see cref="T:ExpressionMath.Expressions.UnaryExpression" />.</summary>
        /// <returns>The modified expression, if it or any subexpression was modified; otherwise, returns the original expression.</returns>
        /// <param name="node">The expression to visit.</param>
        protected internal virtual Expression VisitUnary(UnaryExpression node)
        {
            UnaryExpression after = node.Update(Visit(node.Operand));
            return ExpressionVisitor.ValidateUnary(before, after);
        }

        private static UnaryExpression ValidateUnary(UnaryExpression before, UnaryExpression after)
        {
            if (before != after && before.Method == (MethodInfo)null)
            {
                if (after.Method != (MethodInfo)null)
                    throw Error.MustRewriteWithoutMethod((object)after.Method, (object)"VisitUnary");
                if (before.Operand != null && after.Operand != null)
                    ExpressionVisitor.ValidateChildType(before.Operand.Type, after.Operand.Type, "VisitUnary");
            }
            return after;
        }

        private static BinaryExpression ValidateBinary(BinaryExpression before, BinaryExpression after)
        {
            if (before != after && before.Method == (MethodInfo)null)
            {
                if (after.Method != (MethodInfo)null)
                    throw Error.MustRewriteWithoutMethod((object)after.Method, (object)"VisitBinary");
                ExpressionVisitor.ValidateChildType(before.Left.Type, after.Left.Type, "VisitBinary");
                ExpressionVisitor.ValidateChildType(before.Right.Type, after.Right.Type, "VisitBinary");
            }
            return after;
        }

        private static SwitchExpression ValidateSwitch(SwitchExpression before, SwitchExpression after)
        {
            if (before.Comparison == (MethodInfo)null && after.Comparison != (MethodInfo)null)
                throw Error.MustRewriteWithoutMethod((object)after.Comparison, (object)"VisitSwitch");
            return after;
        }

        private static void ValidateChildType(Type before, Type after, string methodName)
        {
            if (before.IsValueType)
            {
                if (TypeUtils.AreEquivalent(before, after))
                    return;
            }
            else if (!after.IsValueType)
                return;
            throw Error.MustRewriteChildToSameType((object)before, (object)after, (object)methodName);
        }
    }
}
