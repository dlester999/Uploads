﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExpressionMath.Expressions
{
    public sealed class ForExpression : LoopExpression
    {
        public ForExpression(Expression body, Expression sequence) : base(body)
        {
            Sequence = sequence;
        }

        /// <summary>Returns the node type of this expression. Extension nodes should return <see cref="F:ExpressionMath.Expressions.ExpressionType.Extension" /> when overriding this method.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> of the expression.</returns>
        public override ExpressionType NodeType => ExpressionType.For;

        public Expression Sequence { get; }
    }
}
