﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExpressionMath.Expressions
{
    public sealed class WhileExpression : LoopExpression
    {
        public WhileExpression(Expression body, Expression test) : base(body)
        {
            Test = test;
        }

        /// <summary>Returns the node type of this expression. Extension nodes should return <see cref="F:ExpressionMath.Expressions.ExpressionType.Extension" /> when overriding this method.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> of the expression.</returns>
        public override ExpressionType NodeType => ExpressionType.While;

        public Expression Test { get; }
    }
}
