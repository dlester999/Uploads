﻿using System;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents an infinite loop. It can be exited with "break".</summary>
    public abstract class LoopExpression : Expression
    {
        /// <summary>Gets the static type of the expression that this <see cref="T:ExpressionMath.Expressions.Expression" /> represents.</summary>
        /// <returns>The <see cref="P:ExpressionMath.Expressions.LoopExpression.Type" /> that represents the static type of the expression.</returns>
        public override sealed Type Type { get; }

        

        /// <summary>Gets the <see cref="T:ExpressionMath.Expressions.Expression" /> that is the body of the loop.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.Expression" /> that is the body of the loop.</returns>
        public Expression Body { get; }

        internal LoopExpression(Expression body)
        {
            Body = body;
        }

        protected internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitLoop(this);
        }
    }
}