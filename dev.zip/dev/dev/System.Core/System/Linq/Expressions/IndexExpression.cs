﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents indexing a property or array.</summary>
    public sealed class IndexExpression : Expression, IArgumentProvider
    {
        private readonly Expression _instance;
        private readonly PropertyInfo _indexer;
        private IList<Expression> _arguments;

        /// <summary>Returns the node type of this <see cref="T:ExpressionMath.Expressions.Expression" />.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> that represents this expression.</returns>

        public override sealed ExpressionType NodeType { get; }

        /// <summary>Gets the static type of the expression that this <see cref="T:ExpressionMath.Expressions.Expression" /> represents.</summary>
        /// <returns>The <see cref="P:ExpressionMath.Expressions.IndexExpression.Type" /> that represents the static type of the expression.</returns>

        public override sealed Type Type { get; }

        /// <summary>An object to index.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.Expression" /> representing the object to index.</returns>

        public Expression Object { get; }

        /// <summary>Gets the <see cref="T:System.Reflection.PropertyInfo" /> for the property if the expression represents an indexed property, returns null otherwise.</summary>
        /// <returns>The <see cref="T:System.Reflection.PropertyInfo" /> for the property if the expression represents an indexed property, otherwise null.</returns>

        public PropertyInfo Indexer { get; }

        /// <summary>Gets the arguments that will be used to index the property or array.</summary>
        /// <returns>The read-only collection containing the arguments that will be used to index the property or array.</returns>

        public ReadOnlyCollection<Expression> Arguments
        {
            get
            {
                return Expression.ReturnReadOnly<Expression>(ref _arguments);
            }
        }


        int IArgumentProvider.ArgumentCount => _arguments.Count;

        internal IndexExpression(Expression instance, PropertyInfo indexer, IList<Expression> arguments)
        {
            int num = indexer == (PropertyInfo)null ? 1 : 0;
            _instance = instance;
            _indexer = indexer;
            _arguments = arguments;
        }

        /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
        /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
        /// <param name="object">The <see cref="P:ExpressionMath.Expressions.IndexExpression.Object" /> property of the result.</param>
        /// <param name="arguments">The <see cref="P:ExpressionMath.Expressions.IndexExpression.Arguments" /> property of the result.</param>

        public IndexExpression Update(Expression @object, IEnumerable<Expression> arguments)
        {
            if (@object == Object && arguments == Arguments)
                return this;
            return Expression.MakeIndex(@object, Indexer, arguments);
        }


        Expression IArgumentProvider.GetArgument(int index)
        {
            return _arguments[index];
        }

        protected internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitIndex(this);
        }
    }
}
