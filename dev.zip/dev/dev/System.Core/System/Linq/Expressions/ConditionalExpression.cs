﻿using System;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents an expression that has a conditional operator.</summary>
    public class ConditionalExpression : Expression
    {
        private readonly Expression _test;
        private readonly Expression _true;

        /// <summary>Returns the node type of this expression. Extension nodes should return <see cref="F:ExpressionMath.Expressions.ExpressionType.Extension" /> when overriding this method.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> of the expression.</returns>

        public override sealed ExpressionType NodeType
        {
            get
            {
                return ExpressionType.Conditional;
            }
        }

        /// <summary>Gets the static type of the expression that this <see cref="T:ExpressionMath.Expressions.Expression" /> represents.</summary>
        /// <returns>The <see cref="P:ExpressionMath.Expressions.ConditionalExpression.Type" /> that represents the static type of the expression.</returns>
        public override Type Type
        {
            get
            {
                return IfTrue.Type;
            }
        }

        /// <summary>Gets the test of the conditional operation.</summary>
        /// <returns>An <see cref="T:ExpressionMath.Expressions.Expression" /> that represents the test of the conditional operation.</returns>
        public Expression Test
        {
            get
            {
                return _test;
            }
        }

        /// <summary>Gets the expression to execute if the test evaluates to true.</summary>
        /// <returns>An <see cref="T:ExpressionMath.Expressions.Expression" /> that represents the expression to execute if the test is true.</returns>
        public Expression IfTrue
        {
            get
            {
                return _true;
            }
        }

        /// <summary>Gets the expression to execute if the test evaluates to false.</summary>
        /// <returns>An <see cref="T:ExpressionMath.Expressions.Expression" /> that represents the expression to execute if the test is false.</returns>
        public Expression IfFalse
        {
            get
            {
                return GetFalse();
            }
        }

        internal ConditionalExpression(Expression test, Expression ifTrue)
        {
            _test = test;
            _true = ifTrue;
        }

        internal static ConditionalExpression Make(Expression test, Expression ifTrue, Expression ifFalse, Type type)
        {
            if (ifTrue.Type != type || ifFalse.Type != type)
                return new FullConditionalExpressionWithType(test, ifTrue, ifFalse, type);
            if (ifFalse is DefaultExpression && ifFalse.Type == typeof(void))
                return new ConditionalExpression(test, ifTrue);
            return (ConditionalExpression)new FullConditionalExpression(test, ifTrue, ifFalse);
        }

        internal virtual Expression GetFalse()
        {
            return (Expression)Expression.Empty();
        }

        /// <summary>Dispatches to the specific visit method for this node type. For example, <see cref="T:ExpressionMath.Expressions.MethodCallExpression" /> calls the <see cref="M:ExpressionMath.Expressions.ExpressionVisitor.VisitMethodCall(ExpressionMath.Expressions.MethodCallExpression)" />.</summary>
        /// <returns>The result of visiting this node.</returns>
        /// <param name="visitor">The visitor to visit this node with.</param>
        protected internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitConditional(this);
        }

        /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression</summary>
        /// <returns>This expression if no children changed, or an expression with the updated children.</returns>
        /// <param name="test">The <see cref="P:ExpressionMath.Expressions.ConditionalExpression.Test" /> property of the result.</param>
        /// <param name="ifTrue">The <see cref="P:ExpressionMath.Expressions.ConditionalExpression.IfTrue" /> property of the result.</param>
        /// <param name="ifFalse">The <see cref="P:ExpressionMath.Expressions.ConditionalExpression.IfFalse" /> property of the result.</param>
        public ConditionalExpression Update(Expression test, Expression ifTrue, Expression ifFalse)
        {
            if (test == Test && ifTrue == IfTrue && ifFalse == IfFalse)
                return this;
            return Expression.Condition(test, ifTrue, ifFalse, Type);
        }
    }
}
