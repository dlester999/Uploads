﻿using System;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents an expression that has a constant value.</summary>
    public class ConstantExpression : Expression
    {
        private readonly object _value;

        /// <summary>Gets the static type of the expression that this <see cref="T:ExpressionMath.Expressions.Expression" /> represents.</summary>
        /// <returns>The <see cref="P:ExpressionMath.Expressions.ConstantExpression.Type" /> that represents the static type of the expression.</returns>
        public override Type Type => _value == null ? typeof(object) : _value.GetType();

        /// <summary>Returns the node type of this Expression. Extension nodes should return <see cref="F:ExpressionMath.Expressions.ExpressionType.Extension" /> when overriding this method.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> of the expression.</returns>
        public override sealed ExpressionType NodeType => ExpressionType.Constant;

        /// <summary>Gets the value of the constant expression.</summary>
        /// <returns>An <see cref="T:System.Object" /> equal to the value of the represented expression.</returns>
        public object Value => _value;

        internal ConstantExpression(object value)
        {
            _value = value;
        }

        internal static ConstantExpression Make(object value)
        {
            return new ConstantExpression(value);
        }

        /// <summary>Dispatches to the specific visit method for this node type. For example, <see cref="T:ExpressionMath.Expressions.MethodCallExpression" /> calls the <see cref="M:ExpressionMath.Expressions.ExpressionVisitor.VisitMethodCall(ExpressionMath.Expressions.MethodCallExpression)" />.</summary>
        /// <returns>The result of visiting this node.</returns>
        /// <param name="visitor">The visitor to visit this node with.</param>
        protected internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitConstant(this);
        }
    }
}
