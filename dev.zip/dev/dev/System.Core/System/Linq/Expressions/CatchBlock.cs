﻿using System;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents a catch statement in a try block.</summary>
    public sealed class CatchBlock
    {
        internal CatchBlock(Type test, Expression body)
        {
            Test = test;
            Body = body;
        }
        
        /// <summary>Gets the type of <see cref="T:System.Exception" /> this handler catches.</summary>
        /// <returns>The <see cref="T:System.Type" /> object representing the type of <see cref="T:System.Exception" /> this handler catches.</returns>
        public Type Test { get; }

        /// <summary>Gets the body of the catch block.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.Expression" /> object representing the catch body.</returns>
        public Expression Body { get; }

        /// <summary>Returns a <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.</summary>
        /// <returns>A <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.</returns>
        public override string ToString()
        {
            return "";
        }

        /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
        /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
        /// <param name="variable">The <see cref="P:ExpressionMath.Expressions.CatchBlock.Variable" /> property of the result.</param>
        /// <param name="filter">The <see cref="P:ExpressionMath.Expressions.CatchBlock.Filter" /> property of the result.</param>
        /// <param name="body">The <see cref="P:ExpressionMath.Expressions.CatchBlock.Body" /> property of the result.</param>
        public CatchBlock Update(ParameterExpression variable, Expression filter, Expression body)
        {
            if (body == Body)
                return this;

            return new CatchBlock(Test, body);
        }
    }
}
