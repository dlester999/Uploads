﻿using System.Reflection;

namespace ExpressionMath.Expressions
{
    public sealed class TernaryExpression : Expression
    {
        internal TernaryExpression(ExpressionType nodeType, Expression summand, Expression lowerLimit, Expression upperLimit)
        {
            Summand = summand;
            NodeType = nodeType;
            LowerLimit = lowerLimit;
            UpperLimit = upperLimit;
        }

        public sealed override ExpressionType NodeType { get; }

        public Expression Summand { get; }

        public Expression UpperLimit { get; }

        public Expression LowerLimit { get; }

        internal MethodInfo GetMethod()
        {
            return (MethodInfo)null;
        }

        protected sealed internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitTernary(this);
        }

        /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
        /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
        /// <param name="summand">The <see cref="P:ExpressionMath.Expressions.BinaryExpression.Left" /> property of the result. </param>
        /// <param name="LowerLimit">The <see cref="P:ExpressionMath.Expressions.BinaryExpression.Conversion" /> property of the result.</param>
        /// <param name="upperLimit">The <see cref="P:ExpressionMath.Expressions.BinaryExpression.Right" /> property of the result. </param>
        public TernaryExpression Update(Expression summand, Expression lowerLimit, Expression upperLimit)
        {
            if (summand == Summand && lowerLimit == LowerLimit && upperLimit == UpperLimit)
                return this;

            return new TernaryExpression(NodeType, summand, lowerLimit, upperLimit);
        }
    }
}
