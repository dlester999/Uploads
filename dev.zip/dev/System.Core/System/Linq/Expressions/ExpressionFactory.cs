﻿namespace ExpressionMath.Expressions
{
	public static class ExpressionFactory
	{
		public static Expression Add(Expression left, Expression right)
		{
			return new BinaryExpression(ExpressionType.Add, left, right);
		}
	}
}
