﻿using System.Reflection;
using System;

namespace ExpressionMath.Expressions
{
    /// <summary>Provides the base class from which the classes that represent expression tree nodes are derived. It also contains static (Shared in Visual Basic) factory methods to create the various node types. This is an abstract class.</summary>

    public abstract class Expression
    {
        /// <summary>Gets the node type of this <see cref="T:ExpressionMath.Expressions.Expression" />.</summary>
        /// <returns>One of the <see cref="T:ExpressionMath.Expressions.ExpressionType" /> values.</returns>
        public virtual ExpressionType NodeType { get; }

        /// <summary>Gets the static type of the expression that this <see cref="T:ExpressionMath.Expressions.Expression" /> represents.</summary>
        /// <returns>The <see cref="T:System.Type" /> that represents the static type of the expression.</returns>
        public virtual Type Type { get; }


        /// <summary>Initializes a new instance of the <see cref="T:ExpressionMath.Expressions.Expression" /> class.</summary>
        /// <param name="nodeType">The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> to set as the node type.</param>
        /// <param name="type">The <see cref="P:ExpressionMath.Expressions.Expression.Type" /> of this <see cref="T:ExpressionMath.Expressions.Expression" />.</param>
        [Obsolete("use a different constructor that does not take ExpressionType. Then override NodeType and Type properties to provide the values that would be specified to this constructor.")]
        protected Expression(ExpressionType nodeType, Type type)
        {
        }

        /// <summary>Constructs a new instance of <see cref="T:ExpressionMath.Expressions.Expression" />.</summary>
        protected Expression()
        {
        }

        protected abstract internal Expression Accept(ExpressionVisitor visitor);
    }
}
