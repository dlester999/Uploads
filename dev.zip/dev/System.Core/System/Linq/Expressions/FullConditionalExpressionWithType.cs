﻿using System;

namespace ExpressionMath.Expressions
{
    internal class FullConditionalExpressionWithType : FullConditionalExpression
    {
        public override sealed Type Type { get; }

        internal FullConditionalExpressionWithType(Expression test, Expression ifTrue, Expression ifFalse, Type type)
          : base(test, ifTrue, ifFalse)
        {
            Type = type;
        }
    }
}
