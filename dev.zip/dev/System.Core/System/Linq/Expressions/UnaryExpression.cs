﻿using System;
using System.Reflection;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents an expression that has a unary operator.</summary>
    public sealed class UnaryExpression : Expression
    {
		internal UnaryExpression(ExpressionType nodeType, Expression expression)
		{
			Operand = expression;
			NodeType = nodeType;
		}

		/// <summary>Gets the static type of the expression that this <see cref="T:ExpressionMath.Expressions.Expression" /> represents.</summary>
		/// <returns>The <see cref="P:ExpressionMath.Expressions.UnaryExpression.Type" /> that represents the static type of the expression.</returns>
		public override sealed Type Type { get; }

        /// <summary>Returns the node type of this <see cref="T:ExpressionMath.Expressions.Expression" />.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> that represents this expression.</returns>
        public override sealed ExpressionType NodeType { get; }
        
        /// <summary>Gets the operand of the unary operation.</summary>
        /// <returns>An <see cref="T:ExpressionMath.Expressions.Expression" /> that represents the operand of the unary operation.</returns>
        public Expression Operand { get; }
        
        /// <summary>Gets the implementing method for the unary operation.</summary>
        /// <returns>The <see cref="T:System.Reflection.MethodInfo" /> that represents the implementing method.</returns>
        public MethodInfo Method { get; }

        protected internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitUnary(this);
        }

        /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
        /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
        /// <param name="operand">The <see cref="P:ExpressionMath.Expressions.UnaryExpression.Operand" /> property of the result.</param>
        public UnaryExpression Update(Expression operand)
        {
            if (operand == this.Operand)
                return this;

            return new UnaryExpression(NodeType, operand);
        }
    }
}
