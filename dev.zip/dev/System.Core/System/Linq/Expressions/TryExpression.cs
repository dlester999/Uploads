﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents a try/catch/finally/fault block.</summary>
    public sealed class TryExpression : Expression
    {
        internal TryExpression(Type type, Expression body, Expression @finally, ReadOnlyCollection<CatchBlock> handlers)
        {
            Type = type;
            Body = body;
            Handlers = handlers;
            Finally = @finally;
        }

        /// <summary>Gets the static type of the expression that this <see cref="T:ExpressionMath.Expressions.Expression" /> represents.</summary>
        /// <returns>The <see cref="P:ExpressionMath.Expressions.TryExpression.Type" /> that represents the static type of the expression.</returns>

        public override sealed Type Type { get; }

        /// <summary>Returns the node type of this <see cref="T:ExpressionMath.Expressions.Expression" />.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> that represents this expression.</returns>
        public override sealed ExpressionType NodeType => ExpressionType.Try;

        /// <summary>Gets the <see cref="T:ExpressionMath.Expressions.Expression" /> representing the body of the try block.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.Expression" /> representing the body of the try block.</returns>
        public Expression Body { get; }

        /// <summary>Gets the collection of <see cref="T:ExpressionMath.Expressions.CatchBlock" /> expressions associated with the try block.</summary>
        /// <returns>The collection of <see cref="T:ExpressionMath.Expressions.CatchBlock" /> expressions associated with the try block.</returns>
        public ReadOnlyCollection<CatchBlock> Handlers { get; }

        /// <summary>Gets the <see cref="T:ExpressionMath.Expressions.Expression" /> representing the finally block.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.Expression" /> representing the finally block.</returns>
        public Expression Finally { get; }
        
        protected internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitTry(this);
        }

        /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
        /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
        /// <param name="body">The <see cref="P:ExpressionMath.Expressions.TryExpression.Body" /> property of the result.</param>
        /// <param name="handlers">The <see cref="P:ExpressionMath.Expressions.TryExpression.Handlers" /> property of the result.</param>
        /// <param name="finally">The <see cref="P:ExpressionMath.Expressions.TryExpression.Finally" /> property of the result.</param>
        public TryExpression Update(Expression body, IEnumerable<CatchBlock> handlers, Expression @finally)
        {
            if (body == Body && handlers == Handlers && (@finally == Finally))
                return this;

            return new TryExpression(Type, body, @finally, handlers.ToReadOnlyCollection());
        }
    }
}
