﻿using System;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents a label, which can be put in any <see cref="T:ExpressionMath.Expressions.Expression" /> context. If it is jumped to, it will get the value provided by the corresponding <see cref="T:ExpressionMath.Expressions.GotoExpression" />. Otherwise, it receives the value in <see cref="P:ExpressionMath.Expressions.LabelExpression.DefaultValue" />. If the <see cref="T:System.Type" /> equals System.Void, no value should be provided.</summary>
    public sealed class LabelExpression : Expression
    {
        /// <summary>Gets the static type of the expression that this <see cref="T:ExpressionMath.Expressions.Expression" /> represents.</summary>
        /// <returns>The <see cref="P:ExpressionMath.Expressions.LabelExpression.Type" /> that represents the static type of the expression.</returns>

        public override sealed Type Type
        {
            get
            {
                return this._target.Type;
            }
        }

        /// <summary>Returns the node type of this <see cref="T:ExpressionMath.Expressions.Expression" />.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> that represents this expression.</returns>
        public override sealed ExpressionType NodeType => ExpressionType.Label;

        /// <summary>The <see cref="T:ExpressionMath.Expressions.LabelTarget" /> which this label is associated with.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.LabelTarget" /> which this label is associated with.</returns>

        public LabelTarget Target { get; }

        /// <summary>The value of the <see cref="T:ExpressionMath.Expressions.LabelExpression" /> when the label is reached through regular control flow (for example, is not jumped to).</summary>
        /// <returns>The Expression object representing the value of the <see cref="T:ExpressionMath.Expressions.LabelExpression" />.</returns>

        public Expression DefaultValue { get; }

        internal LabelExpression(LabelTarget label, Expression defaultValue)
        {
            Target = label;
            DefaultValue = defaultValue;
        }

        protected internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitLabel(this);
        }

        /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
        /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
        /// <param name="target">The <see cref="P:ExpressionMath.Expressions.LabelExpression.Target" /> property of the result.</param>
        /// <param name="defaultValue">The <see cref="P:ExpressionMath.Expressions.LabelExpression.DefaultValue" /> property of the result</param>

        public LabelExpression Update(LabelTarget target, Expression defaultValue)
        {
            if (target == this.Target && defaultValue == this.DefaultValue)
                return this;
            return Expression.Label(target, defaultValue);
        }
    }
}
