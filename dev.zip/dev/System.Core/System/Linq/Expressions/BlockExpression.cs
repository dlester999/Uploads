﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents a block that contains a sequence of expressions where variables can be defined.</summary>
    public class BlockExpression : Expression
  {
    /// <summary>Gets the expressions in this block.</summary>
    /// <returns>The read-only collection containing all the expressions in this block.</returns>
    
    public ReadOnlyCollection<Expression> Expressions
    {
       get
      {
        return this.GetOrMakeExpressions();
      }
    }

    /// <summary>Gets the variables defined in this block.</summary>
    /// <returns>The read-only collection containing all the variables defined in this block.</returns>
    
    public ReadOnlyCollection<ParameterExpression> Variables
    {
       get
      {
        return this.GetOrMakeVariables();
      }
    }

    /// <summary>Gets the last expression in this block.</summary>
    /// <returns>The <see cref="T:ExpressionMath.Expressions.Expression" /> object representing the last expression in this block.</returns>
    
    public Expression Result
    {
       get
      {
        return this.GetExpression(this.ExpressionCount - 1);
      }
    }

    /// <summary>Returns the node type of this expression. Extension nodes should return <see cref="F:ExpressionMath.Expressions.ExpressionType.Extension" /> when overriding this method.</summary>
    /// <returns>The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> of the expression.</returns>
    
    public override sealed ExpressionType NodeType
    {
       get
      {
        return ExpressionType.Block;
      }
    }

    /// <summary>Gets the static type of the expression that this <see cref="T:ExpressionMath.Expressions.Expression" /> represents.</summary>
    /// <returns>The <see cref="P:ExpressionMath.Expressions.BlockExpression.Type" /> that represents the static type of the expression.</returns>
    
    public override Type Type
    {
       get
      {
        return this.GetExpression(this.ExpressionCount - 1).Type;
      }
    }

    internal virtual int ExpressionCount
    {
      get
      {
        throw ContractUtils.Unreachable;
      }
    }

    internal virtual int VariableCount
    {
      get
      {
        return 0;
      }
    }

    internal BlockExpression()
    {
    }

    /// <summary>Dispatches to the specific visit method for this node type. For example, <see cref="T:ExpressionMath.Expressions.MethodCallExpression" /> calls the <see cref="M:ExpressionMath.Expressions.ExpressionVisitor.VisitMethodCall(ExpressionMath.Expressions.MethodCallExpression)" />.</summary>
    /// <returns>The result of visiting this node.</returns>
    /// <param name="visitor">The visitor to visit this node with.</param>
    
    protected internal override Expression Accept(ExpressionVisitor visitor)
    {
      return visitor.VisitBlock(this);
    }

    /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
    /// <returns>This expression if no children changed, or an expression with the updated children.</returns>
    /// <param name="variables">The <see cref="P:ExpressionMath.Expressions.BlockExpression.Variables" /> property of the result. </param>
    /// <param name="expressions">The <see cref="P:ExpressionMath.Expressions.BlockExpression.Expressions" /> property of the result. </param>
    
    public BlockExpression Update(IEnumerable<ParameterExpression> variables, IEnumerable<Expression> expressions)
    {
      if (variables == this.Variables && expressions == this.Expressions)
        return this;
      return Expression.Block(this.Type, variables, expressions);
    }

    internal virtual Expression GetExpression(int index)
    {
      throw ContractUtils.Unreachable;
    }

    internal virtual ReadOnlyCollection<Expression> GetOrMakeExpressions()
    {
      throw ContractUtils.Unreachable;
    }

    internal virtual ParameterExpression GetVariable(int index)
    {
      throw ContractUtils.Unreachable;
    }

    internal virtual ReadOnlyCollection<ParameterExpression> GetOrMakeVariables()
    {
      return EmptyReadOnlyCollection<ParameterExpression>.Instance;
    }

    internal virtual BlockExpression Rewrite(ReadOnlyCollection<ParameterExpression> variables, Expression[] args)
    {
      throw ContractUtils.Unreachable;
    }

    internal static ReadOnlyCollection<Expression> ReturnReadOnlyExpressions(BlockExpression provider, ref object collection)
    {
      Expression expression = collection as Expression;
      if (expression != null)
        Interlocked.CompareExchange(ref collection, (object) new ReadOnlyCollection<Expression>((IList<Expression>) new BlockExpressionList(provider, expression)), (object) expression);
      return (ReadOnlyCollection<Expression>) collection;
    }
  }
}
