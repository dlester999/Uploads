﻿using System;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents a named parameter expression.</summary>
    public class ParameterExpression : Expression
    {
        /// <summary>Gets the static type of the expression that this <see cref="T:ExpressionMath.Expressions.Expression" /> represents.</summary>
        /// <returns>The <see cref="P:ExpressionMath.Expressions.ParameterExpression.Type" /> that represents the static type of the expression.</returns>
        public override Type Type { get; }

        /// <summary>Returns the node type of this <see cref="T:ExpressionMath.Expressions.Expression" />.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> that represents this expression.</returns>
        public override sealed ExpressionType NodeType { get; }

        /// <summary>Gets the name of the parameter or variable.</summary>
        /// <returns>A <see cref="T:System.String" /> that contains the name of the parameter.</returns>
        public string Name { get; }


        internal ParameterExpression(string name)
        {
            Name = name;
        }

        internal static ParameterExpression Make(Type type, string name, bool isByRef)
        {
            if (isByRef)
                return (ParameterExpression)new ByRefParameterExpression(type, name);
            if (!type.IsEnum)
            {
                switch (Type.GetTypeCode(type))
                {
                    case TypeCode.Object:
                        if (type == typeof(object))
                            return new ParameterExpression(name);
                        if (type == typeof(Exception))
                            return (ParameterExpression)new PrimitiveParameterExpression<Exception>(name);
                        if (type == typeof(object[]))
                            return (ParameterExpression)new PrimitiveParameterExpression<object[]>(name);
                        break;
                    case TypeCode.DBNull:
                        return (ParameterExpression)new PrimitiveParameterExpression<DBNull>(name);
                    case TypeCode.Boolean:
                        return (ParameterExpression)new PrimitiveParameterExpression<bool>(name);
                    case TypeCode.Char:
                        return (ParameterExpression)new PrimitiveParameterExpression<char>(name);
                    case TypeCode.SByte:
                        return (ParameterExpression)new PrimitiveParameterExpression<sbyte>(name);
                    case TypeCode.Byte:
                        return (ParameterExpression)new PrimitiveParameterExpression<byte>(name);
                    case TypeCode.Int16:
                        return (ParameterExpression)new PrimitiveParameterExpression<short>(name);
                    case TypeCode.UInt16:
                        return (ParameterExpression)new PrimitiveParameterExpression<ushort>(name);
                    case TypeCode.Int32:
                        return (ParameterExpression)new PrimitiveParameterExpression<int>(name);
                    case TypeCode.UInt32:
                        return (ParameterExpression)new PrimitiveParameterExpression<uint>(name);
                    case TypeCode.Int64:
                        return (ParameterExpression)new PrimitiveParameterExpression<long>(name);
                    case TypeCode.UInt64:
                        return (ParameterExpression)new PrimitiveParameterExpression<ulong>(name);
                    case TypeCode.Single:
                        return (ParameterExpression)new PrimitiveParameterExpression<float>(name);
                    case TypeCode.Double:
                        return (ParameterExpression)new PrimitiveParameterExpression<double>(name);
                    case TypeCode.Decimal:
                        return (ParameterExpression)new PrimitiveParameterExpression<Decimal>(name);
                    case TypeCode.DateTime:
                        return (ParameterExpression)new PrimitiveParameterExpression<DateTime>(name);
                    case TypeCode.String:
                        return (ParameterExpression)new PrimitiveParameterExpression<string>(name);
                }
            }
            return (ParameterExpression)new TypedParameterExpression(type, name);
        }


        /// <summary>Dispatches to the specific visit method for this node type. For example, <see cref="T:ExpressionMath.Expressions.MethodCallExpression" /> calls the <see cref="M:ExpressionMath.Expressions.ExpressionVisitor.VisitMethodCall(ExpressionMath.Expressions.MethodCallExpression)" />.</summary>
        /// <returns>The result of visiting this node.</returns>
        /// <param name="visitor">The visitor to visit this node with.</param>
        protected internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitParameter(this);
        }
    }
}
