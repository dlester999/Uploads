﻿// Decompiled with JetBrains decompiler
// Type: System.Linq.Expressions.SwitchCase
// Assembly: System.Core, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089
// MVID: AB5FC141-14CC-423D-98F6-C57F5EC05199
// Assembly location: C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Core.dll

using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace System.Linq.Expressions
{
    /// <summary>Represents one case of a <see cref="T:System.Linq.Expressions.SwitchExpression" />.</summary>
    public sealed class SwitchCase
    {
        private readonly ReadOnlyCollection<Expression> _testValues;
        private readonly Expression _body;

        /// <summary>Gets the values of this case. This case is selected for execution when the <see cref="P:System.Linq.Expressions.SwitchExpression.SwitchValue" /> matches any of these values.</summary>
        /// <returns>The read-only collection of the values for this case block.</returns>
        public ReadOnlyCollection<Expression> TestValues
        {
            get
            {
                return this._testValues;
            }
        }

        /// <summary>Gets the body of this case.</summary>
        /// <returns>The <see cref="T:System.Linq.Expressions.Expression" /> object that represents the body of the case block.</returns>
        public Expression Body
        {
            get
            {
                return this._body;
            }
        }

        internal SwitchCase(Expression body, ReadOnlyCollection<Expression> testValues)
        {
            this._body = body;
            this._testValues = testValues;
        }

        /// <summary>Returns a <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.</summary>
        /// <returns>A <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.</returns>
        public override string ToString()
        {
            return ExpressionStringBuilder.SwitchCaseToString(this);
        }

        /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
        /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
        /// <param name="testValues">The <see cref="P:System.Linq.Expressions.SwitchCase.TestValues" /> property of the result.</param>
        /// <param name="body">The <see cref="P:System.Linq.Expressions.SwitchCase.Body" /> property of the result.</param>
        public SwitchCase Update(IEnumerable<Expression> testValues, Expression body)
        {
            if (testValues == this.TestValues && body == this.Body)
                return this;
            return Expression.SwitchCase(body, testValues);
        }
    }
}
