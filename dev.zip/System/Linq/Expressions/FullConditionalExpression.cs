﻿// Decompiled with JetBrains decompiler
// Type: System.Linq.Expressions.FullConditionalExpression
// Assembly: System.Core, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089
// MVID: AB5FC141-14CC-423D-98F6-C57F5EC05199
// Assembly location: C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Core.dll

namespace System.Linq.Expressions
{
  internal class FullConditionalExpression : ConditionalExpression
  {
    private readonly Expression _false;

    internal FullConditionalExpression(Expression test, Expression ifTrue, Expression ifFalse)
      : base(test, ifTrue)
    {
      this._false = ifFalse;
    }

    internal override Expression GetFalse()
    {
      return this._false;
    }
  }
}
