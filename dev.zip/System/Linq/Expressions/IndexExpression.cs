﻿// Decompiled with JetBrains decompiler
// Type: System.Linq.Expressions.IndexExpression
// Assembly: System.Core, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089
// MVID: AB5FC141-14CC-423D-98F6-C57F5EC05199
// Assembly location: C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Core.dll

using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Reflection;

namespace System.Linq.Expressions
{
  /// <summary>Represents indexing a property or array.</summary>
  [DebuggerTypeProxy(typeof (Expression.IndexExpressionProxy))]
  
  public sealed class IndexExpression : Expression, IArgumentProvider
  {
    private readonly Expression _instance;
    private readonly PropertyInfo _indexer;
    private IList<Expression> _arguments;

    /// <summary>Returns the node type of this <see cref="T:System.Linq.Expressions.Expression" />.</summary>
    /// <returns>The <see cref="T:System.Linq.Expressions.ExpressionType" /> that represents this expression.</returns>
    
    public override sealed ExpressionType NodeType
    {
       get
      {
        return ExpressionType.Index;
      }
    }

    /// <summary>Gets the static type of the expression that this <see cref="T:System.Linq.Expressions.Expression" /> represents.</summary>
    /// <returns>The <see cref="P:System.Linq.Expressions.IndexExpression.Type" /> that represents the static type of the expression.</returns>
    
    public override sealed Type Type
    {
       get
      {
        if (this._indexer != (PropertyInfo) null)
          return this._indexer.PropertyType;
        return this._instance.Type.GetElementType();
      }
    }

    /// <summary>An object to index.</summary>
    /// <returns>The <see cref="T:System.Linq.Expressions.Expression" /> representing the object to index.</returns>
    
    public Expression Object
    {
       get
      {
        return this._instance;
      }
    }

    /// <summary>Gets the <see cref="T:System.Reflection.PropertyInfo" /> for the property if the expression represents an indexed property, returns null otherwise.</summary>
    /// <returns>The <see cref="T:System.Reflection.PropertyInfo" /> for the property if the expression represents an indexed property, otherwise null.</returns>
    
    public PropertyInfo Indexer
    {
       get
      {
        return this._indexer;
      }
    }

    /// <summary>Gets the arguments that will be used to index the property or array.</summary>
    /// <returns>The read-only collection containing the arguments that will be used to index the property or array.</returns>
    
    public ReadOnlyCollection<Expression> Arguments
    {
       get
      {
        return Expression.ReturnReadOnly<Expression>(ref this._arguments);
      }
    }

    
    int IArgumentProvider.ArgumentCount
    {
       get
      {
        return this._arguments.Count;
      }
    }

    internal IndexExpression(Expression instance, PropertyInfo indexer, IList<Expression> arguments)
    {
      int num = indexer == (PropertyInfo) null ? 1 : 0;
      this._instance = instance;
      this._indexer = indexer;
      this._arguments = arguments;
    }

    /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
    /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
    /// <param name="object">The <see cref="P:System.Linq.Expressions.IndexExpression.Object" /> property of the result.</param>
    /// <param name="arguments">The <see cref="P:System.Linq.Expressions.IndexExpression.Arguments" /> property of the result.</param>
    
    public IndexExpression Update(Expression @object, IEnumerable<Expression> arguments)
    {
      if (@object == this.Object && arguments == this.Arguments)
        return this;
      return Expression.MakeIndex(@object, this.Indexer, arguments);
    }

    
    Expression IArgumentProvider.GetArgument(int index)
    {
      return this._arguments[index];
    }

    protected internal override Expression Accept(ExpressionVisitor visitor)
    {
      return visitor.VisitIndex(this);
    }

    internal Expression Rewrite(Expression instance, Expression[] arguments)
    {
      return (Expression) Expression.MakeIndex(instance, this._indexer, (IEnumerable<Expression>) ((IList<Expression>) arguments ?? this._arguments));
    }
  }
}
