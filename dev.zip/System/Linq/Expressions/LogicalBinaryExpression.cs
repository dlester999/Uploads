﻿// Decompiled with JetBrains decompiler
// Type: System.Linq.Expressions.LogicalBinaryExpression
// Assembly: System.Core, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089
// MVID: AB5FC141-14CC-423D-98F6-C57F5EC05199
// Assembly location: C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Core.dll

namespace System.Linq.Expressions
{
  internal sealed class LogicalBinaryExpression : BinaryExpression
  {
    private readonly ExpressionType _nodeType;

    public override sealed Type Type
    {
      get
      {
        return typeof (bool);
      }
    }

    public override sealed ExpressionType NodeType
    {
      get
      {
        return this._nodeType;
      }
    }

    internal LogicalBinaryExpression(ExpressionType nodeType, Expression left, Expression right)
      : base(left, right)
    {
      this._nodeType = nodeType;
    }
  }
}
