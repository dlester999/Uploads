﻿// Decompiled with JetBrains decompiler
// Type: System.Linq.Expressions.TypeBinaryExpression
// Assembly: System.Core, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089
// MVID: AB5FC141-14CC-423D-98F6-C57F5EC05199
// Assembly location: C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Core.dll

using System.Collections.Generic;
using System.Diagnostics;
using System.Dynamic.Utils;

namespace System.Linq.Expressions
{
  /// <summary>Represents an operation between an expression and a type.</summary>
  [DebuggerTypeProxy(typeof (Expression.TypeBinaryExpressionProxy))]
  
  public sealed class TypeBinaryExpression : Expression
  {
    private readonly Expression _expression;
    private readonly Type _typeOperand;
    private readonly ExpressionType _nodeKind;

    /// <summary>Gets the static type of the expression that this <see cref="P:System.Linq.Expressions.TypeBinaryExpression.Expression" /> represents.</summary>
    /// <returns>The <see cref="P:System.Linq.Expressions.TypeBinaryExpression.Type" /> that represents the static type of the expression.</returns>
    
    public override sealed Type Type
    {
       get
      {
        return typeof (bool);
      }
    }

    /// <summary>Returns the node type of this Expression. Extension nodes should return <see cref="F:System.Linq.Expressions.ExpressionType.Extension" /> when overriding this method.</summary>
    /// <returns>The <see cref="T:System.Linq.Expressions.ExpressionType" /> of the expression.</returns>
    
    public override sealed ExpressionType NodeType
    {
       get
      {
        return this._nodeKind;
      }
    }

    /// <summary>Gets the expression operand of a type test operation.</summary>
    /// <returns>An <see cref="T:System.Linq.Expressions.Expression" /> that represents the expression operand of a type test operation.</returns>
    
    public Expression Expression
    {
       get
      {
        return this._expression;
      }
    }

    /// <summary>Gets the type operand of a type test operation.</summary>
    /// <returns>A <see cref="T:System.Type" /> that represents the type operand of a type test operation.</returns>
    
    public Type TypeOperand
    {
       get
      {
        return this._typeOperand;
      }
    }

    internal TypeBinaryExpression(Expression expression, Type typeOperand, ExpressionType nodeKind)
    {
      this._expression = expression;
      this._typeOperand = typeOperand;
      this._nodeKind = nodeKind;
    }

    internal Expression ReduceTypeEqual()
    {
      Type type = this.Expression.Type;
      if (type.IsValueType && !type.IsNullableType())
        return (Expression) Expression.Block(this.Expression, (Expression) Expression.Constant((object) (type == this._typeOperand.GetNonNullableType())));
      if (this.Expression.NodeType == ExpressionType.Constant)
        return this.ReduceConstantTypeEqual();
      if (type.IsSealed && type == this._typeOperand)
      {
        if (type.IsNullableType())
          return (Expression) Expression.NotEqual(this.Expression, (Expression) Expression.Constant((object) null, this.Expression.Type));
        return (Expression) Expression.ReferenceNotEqual(this.Expression, (Expression) Expression.Constant((object) null, this.Expression.Type));
      }
      ParameterExpression expression1 = this.Expression as ParameterExpression;
      if (expression1 != null && !expression1.IsByRef)
        return this.ByValParameterTypeEqual(expression1);
      ParameterExpression parameterExpression = Expression.Parameter(typeof (object));
      Expression expression2 = this.Expression;
      if (!TypeUtils.AreReferenceAssignable(typeof (object), expression2.Type))
        expression2 = (Expression) Expression.Convert(expression2, typeof (object));
      return (Expression) Expression.Block((IEnumerable<ParameterExpression>) new ParameterExpression[1]{ parameterExpression }, new Expression[2]{ (Expression) Expression.Assign((Expression) parameterExpression, expression2), this.ByValParameterTypeEqual(parameterExpression) });
    }

    private Expression ByValParameterTypeEqual(ParameterExpression value)
    {
      Expression expression = (Expression) Expression.Call((Expression) value, typeof (object).GetMethod("GetType"));
      if (this._typeOperand.IsInterface)
      {
        ParameterExpression parameterExpression = Expression.Parameter(typeof (Type));
        expression = (Expression) Expression.Block((IEnumerable<ParameterExpression>) new ParameterExpression[1]
        {
          parameterExpression
        }, new Expression[2]
        {
          (Expression) Expression.Assign((Expression) parameterExpression, expression),
          (Expression) parameterExpression
        });
      }
      return (Expression) Expression.AndAlso((Expression) Expression.ReferenceNotEqual((Expression) value, (Expression) Expression.Constant((object) null)), (Expression) Expression.ReferenceEqual(expression, (Expression) Expression.Constant((object) this._typeOperand.GetNonNullableType(), typeof (Type))));
    }

    private Expression ReduceConstantTypeEqual()
    {
      ConstantExpression expression = this.Expression as ConstantExpression;
      if (expression.Value == null)
        return (Expression) Expression.Constant((object) false);
      return (Expression) Expression.Constant((object) (this._typeOperand.GetNonNullableType() == expression.Value.GetType()));
    }

    protected internal override Expression Accept(ExpressionVisitor visitor)
    {
      return visitor.VisitTypeBinary(this);
    }

    /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
    /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
    /// <param name="expression">The <see cref="P:System.Linq.Expressions.TypeBinaryExpression.Expression" /> property of the result.</param>
    
    public TypeBinaryExpression Update(Expression expression)
    {
      if (expression == this.Expression)
        return this;
      if (this.NodeType == ExpressionType.TypeIs)
        return Expression.TypeIs(expression, this.TypeOperand);
      return Expression.TypeEqual(expression, this.TypeOperand);
    }
  }
}
