﻿// Decompiled with JetBrains decompiler
// Type: System.Linq.Expressions.SwitchExpression
// Assembly: System.Core, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089
// MVID: AB5FC141-14CC-423D-98F6-C57F5EC05199
// Assembly location: C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Core.dll

using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;

namespace System.Linq.Expressions
{
    /// <summary>Represents a control expression that handles multiple selections by passing control to <see cref="T:System.Linq.Expressions.SwitchCase" />.</summary>
    public sealed class SwitchExpression : Expression
    {
        private readonly Type _type;
        private readonly Expression _switchValue;
        private readonly ReadOnlyCollection<SwitchCase> _cases;
        private readonly Expression _defaultBody;
        private readonly MethodInfo _comparison;

        /// <summary>Gets the static type of the expression that this <see cref="T:System.Linq.Expressions.Expression" /> represents.</summary>
        /// <returns>The <see cref="P:System.Linq.Expressions.SwitchExpression.Type" /> that represents the static type of the expression.</returns>
        public override sealed Type Type
        {
            get
            {
                return this._type;
            }
        }

        /// <summary>Returns the node type of this Expression. Extension nodes should return <see cref="F:System.Linq.Expressions.ExpressionType.Extension" /> when overriding this method.</summary>
        /// <returns>The <see cref="T:System.Linq.Expressions.ExpressionType" /> of the expression.</returns>
        public override sealed ExpressionType NodeType
        {
            get
            {
                return ExpressionType.Switch;
            }
        }

        /// <summary>Gets the test for the switch.</summary>
        /// <returns>The <see cref="T:System.Linq.Expressions.Expression" /> object representing the test for the switch.</returns>
        public Expression SwitchValue
        {
            get
            {
                return this._switchValue;
            }
        }

        /// <summary>Gets the collection of <see cref="T:System.Linq.Expressions.SwitchCase" /> objects for the switch.</summary>
        /// <returns>The collection of <see cref="T:System.Linq.Expressions.SwitchCase" /> objects.</returns>
        public ReadOnlyCollection<SwitchCase> Cases
        {
            get
            {
                return this._cases;
            }
        }

        /// <summary>Gets the test for the switch.</summary>
        /// <returns>The <see cref="T:System.Linq.Expressions.Expression" /> object representing the test for the switch.</returns>
        public Expression DefaultBody
        {
            get
            {
                return this._defaultBody;
            }
        }

        /// <summary>Gets the equality comparison method, if any.</summary>
        /// <returns>The <see cref="T:System.Reflection.MethodInfo" /> object representing the equality comparison method.</returns>
        public MethodInfo Comparison
        {
            get
            {
                return this._comparison;
            }
        }

        internal bool IsLifted
        {
            get
            {
                if (!this._switchValue.Type.IsNullableType())
                    return false;
                if (!(this._comparison == (MethodInfo)null))
                    return !TypeUtils.AreEquivalent(this._switchValue.Type, this._comparison.GetParametersCached()[0].ParameterType.GetNonRefType());
                return true;
            }
        }

        internal SwitchExpression(Type type, Expression switchValue, Expression defaultBody, MethodInfo comparison, ReadOnlyCollection<SwitchCase> cases)
        {
            this._type = type;
            this._switchValue = switchValue;
            this._defaultBody = defaultBody;
            this._comparison = comparison;
            this._cases = cases;
        }

        protected internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitSwitch(this);
        }

        /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
        /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
        /// <param name="switchValue">The <see cref="P:System.Linq.Expressions.SwitchExpression.SwitchValue" /> property of the result.</param>
        /// <param name="cases">The <see cref="P:System.Linq.Expressions.SwitchExpression.Cases" /> property of the result.</param>
        /// <param name="defaultBody">The <see cref="P:System.Linq.Expressions.SwitchExpression.DefaultBody" /> property of the result.</param>
        public SwitchExpression Update(Expression switchValue, IEnumerable<SwitchCase> cases, Expression defaultBody)
        {
            if (switchValue == this.SwitchValue && cases == this.Cases && defaultBody == this.DefaultBody)
                return this;
            return Expression.Switch(this.Type, switchValue, defaultBody, this.Comparison, cases);
        }
    }
}
