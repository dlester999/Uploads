﻿// Decompiled with JetBrains decompiler
// Type: System.Linq.Expressions.UnaryExpression
// Assembly: System.Core, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089
// MVID: AB5FC141-14CC-423D-98F6-C57F5EC05199
// Assembly location: C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Core.dll

using System.Reflection;

namespace System.Linq.Expressions
{
    /// <summary>Represents an expression that has a unary operator.</summary>
    public sealed class UnaryExpression : Expression
    {
        /// <summary>Gets the static type of the expression that this <see cref="T:System.Linq.Expressions.Expression" /> represents.</summary>
        /// <returns>The <see cref="P:System.Linq.Expressions.UnaryExpression.Type" /> that represents the static type of the expression.</returns>
        public override sealed Type Type { get; }
        

        /// <summary>Returns the node type of this <see cref="T:System.Linq.Expressions.Expression" />.</summary>
        /// <returns>The <see cref="T:System.Linq.Expressions.ExpressionType" /> that represents this expression.</returns>
        public override sealed ExpressionType NodeType { get; }
        
        /// <summary>Gets the operand of the unary operation.</summary>
        /// <returns>An <see cref="T:System.Linq.Expressions.Expression" /> that represents the operand of the unary operation.</returns>
        public Expression Operand { get; }
        
        /// <summary>Gets the implementing method for the unary operation.</summary>
        /// <returns>The <see cref="T:System.Reflection.MethodInfo" /> that represents the implementing method.</returns>
        public MethodInfo Method { get; }


        /// <summary>Gets a value that indicates whether the expression tree node can be reduced.</summary>
        /// <returns>True if a node can be reduced, otherwise false.</returns>
        public override bool CanReduce
        {
            get
            {
                switch (NodeType)
                {
                    case ExpressionType.PreIncrementAssign:
                    case ExpressionType.PreDecrementAssign:
                    case ExpressionType.PostIncrementAssign:
                    case ExpressionType.PostDecrementAssign:
                        return true;
                    default:
                        return false;
                }
            }
        }
        
        internal UnaryExpression(ExpressionType nodeType, Expression expression, Type type, MethodInfo method)
        {
            Operand = expression;
            Method = method;
            NodeType = nodeType;
            Type = type;
        }

        protected internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitUnary(this);
        }

        /// <summary>Reduces the expression node to a simpler expression. </summary>
        /// <returns>The reduced expression.</returns>
        public override Expression Reduce()
        {
            //if (!this.CanReduce)
                return (Expression)this;
            
        }


        /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
        /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
        /// <param name="operand">The <see cref="P:System.Linq.Expressions.UnaryExpression.Operand" /> property of the result.</param>
        public UnaryExpression Update(Expression operand)
        {
            if (operand == this.Operand)
                return this;

            return Expression.MakeUnary(this.NodeType, operand, this.Type, this.Method);
        }
    }
}
