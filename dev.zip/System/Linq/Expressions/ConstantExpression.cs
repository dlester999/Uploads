﻿// Decompiled with JetBrains decompiler
// Type: System.Linq.Expressions.ConstantExpression
// Assembly: System.Core, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089
// MVID: AB5FC141-14CC-423D-98F6-C57F5EC05199
// Assembly location: C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Core.dll

using System.Diagnostics;

namespace System.Linq.Expressions
{
  /// <summary>Represents an expression that has a constant value.</summary>
  [DebuggerTypeProxy(typeof (Expression.ConstantExpressionProxy))]
  
  public class ConstantExpression : Expression
  {
    private readonly object _value;

    /// <summary>Gets the static type of the expression that this <see cref="T:System.Linq.Expressions.Expression" /> represents.</summary>
    /// <returns>The <see cref="P:System.Linq.Expressions.ConstantExpression.Type" /> that represents the static type of the expression.</returns>
    
    public override Type Type
    {
       get
      {
        if (this._value == null)
          return typeof (object);
        return this._value.GetType();
      }
    }

    /// <summary>Returns the node type of this Expression. Extension nodes should return <see cref="F:System.Linq.Expressions.ExpressionType.Extension" /> when overriding this method.</summary>
    /// <returns>The <see cref="T:System.Linq.Expressions.ExpressionType" /> of the expression.</returns>
    
    public override sealed ExpressionType NodeType
    {
       get
      {
        return ExpressionType.Constant;
      }
    }

    /// <summary>Gets the value of the constant expression.</summary>
    /// <returns>An <see cref="T:System.Object" /> equal to the value of the represented expression.</returns>
    
    public object Value
    {
       get
      {
        return this._value;
      }
    }

    internal ConstantExpression(object value)
    {
      this._value = value;
    }

    internal static ConstantExpression Make(object value, Type type)
    {
      if (value == null && type == typeof (object) || value != null && value.GetType() == type)
        return new ConstantExpression(value);
      return (ConstantExpression) new TypedConstantExpression(value, type);
    }

    /// <summary>Dispatches to the specific visit method for this node type. For example, <see cref="T:System.Linq.Expressions.MethodCallExpression" /> calls the <see cref="M:System.Linq.Expressions.ExpressionVisitor.VisitMethodCall(System.Linq.Expressions.MethodCallExpression)" />.</summary>
    /// <returns>The result of visiting this node.</returns>
    /// <param name="visitor">The visitor to visit this node with.</param>
    
    protected internal override Expression Accept(ExpressionVisitor visitor)
    {
      return visitor.VisitConstant(this);
    }
  }
}
