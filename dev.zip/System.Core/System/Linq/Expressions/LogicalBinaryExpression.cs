﻿using System;

namespace ExpressionMath.Expressions
{
    internal sealed class LogicalBinaryExpression : BinaryExpression
    {
        public override sealed Type Type => typeof(bool);

        public override sealed ExpressionType NodeType { get; }

        internal LogicalBinaryExpression(ExpressionType nodeType, Expression left, Expression right)
          : base(left, right)
        {
            NodeType = nodeType;
        }
    }
}
