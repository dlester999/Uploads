﻿// Decompiled with JetBrains decompiler
// Type: ExpressionMath.Expressions.TryExpression
// Assembly: System.Core, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089
// MVID: AB5FC141-14CC-423D-98F6-C57F5EC05199
// Assembly location: C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Core.dll

using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace ExpressionMath.Expressions
{
  /// <summary>Represents a try/catch/finally/fault block.</summary>
  public sealed class TryExpression : Expression
  {
    private readonly Type _type;
    private readonly Expression _body;
    private readonly ReadOnlyCollection<CatchBlock> _handlers;
    private readonly Expression _finally;
    private readonly Expression _fault;

    /// <summary>Gets the static type of the expression that this <see cref="T:ExpressionMath.Expressions.Expression" /> represents.</summary>
    /// <returns>The <see cref="P:ExpressionMath.Expressions.TryExpression.Type" /> that represents the static type of the expression.</returns>
    
    public override sealed Type Type
    {
       get
      {
        return this._type;
      }
    }

    /// <summary>Returns the node type of this <see cref="T:ExpressionMath.Expressions.Expression" />.</summary>
    /// <returns>The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> that represents this expression.</returns>
    
    public override sealed ExpressionType NodeType
    {
       get
      {
        return ExpressionType.Try;
      }
    }

    /// <summary>Gets the <see cref="T:ExpressionMath.Expressions.Expression" /> representing the body of the try block.</summary>
    /// <returns>The <see cref="T:ExpressionMath.Expressions.Expression" /> representing the body of the try block.</returns>
    
    public Expression Body
    {
       get
      {
        return this._body;
      }
    }

    /// <summary>Gets the collection of <see cref="T:ExpressionMath.Expressions.CatchBlock" /> expressions associated with the try block.</summary>
    /// <returns>The collection of <see cref="T:ExpressionMath.Expressions.CatchBlock" /> expressions associated with the try block.</returns>
    
    public ReadOnlyCollection<CatchBlock> Handlers
    {
       get
      {
        return this._handlers;
      }
    }

    /// <summary>Gets the <see cref="T:ExpressionMath.Expressions.Expression" /> representing the finally block.</summary>
    /// <returns>The <see cref="T:ExpressionMath.Expressions.Expression" /> representing the finally block.</returns>
    
    public Expression Finally
    {
       get
      {
        return this._finally;
      }
    }

    /// <summary>Gets the <see cref="T:ExpressionMath.Expressions.Expression" /> representing the fault block.</summary>
    /// <returns>The <see cref="T:ExpressionMath.Expressions.Expression" /> representing the fault block.</returns>
    
    public Expression Fault
    {
       get
      {
        return this._fault;
      }
    }

    internal TryExpression(Type type, Expression body, Expression @finally, Expression fault, ReadOnlyCollection<CatchBlock> handlers)
    {
      this._type = type;
      this._body = body;
      this._handlers = handlers;
      this._finally = @finally;
      this._fault = fault;
    }

    protected internal override Expression Accept(ExpressionVisitor visitor)
    {
      return visitor.VisitTry(this);
    }

    /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
    /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
    /// <param name="body">The <see cref="P:ExpressionMath.Expressions.TryExpression.Body" /> property of the result.</param>
    /// <param name="handlers">The <see cref="P:ExpressionMath.Expressions.TryExpression.Handlers" /> property of the result.</param>
    /// <param name="finally">The <see cref="P:ExpressionMath.Expressions.TryExpression.Finally" /> property of the result.</param>
    /// <param name="fault">The <see cref="P:ExpressionMath.Expressions.TryExpression.Fault" /> property of the result.</param>
    
    public TryExpression Update(Expression body, IEnumerable<CatchBlock> handlers, Expression @finally, Expression fault)
    {
      if (body == this.Body && handlers == this.Handlers && (@finally == this.Finally && fault == this.Fault))
        return this;
      return Expression.MakeTry(this.Type, body, @finally, fault, handlers);
    }
  }
}
