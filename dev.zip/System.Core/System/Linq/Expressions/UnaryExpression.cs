﻿// Decompiled with JetBrains decompiler
// Type: ExpressionMath.Expressions.UnaryExpression
// Assembly: System.Core, Version=4.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089
// MVID: AB5FC141-14CC-423D-98F6-C57F5EC05199
// Assembly location: C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Core.dll

using System.Reflection;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents an expression that has a unary operator.</summary>
    public sealed class UnaryExpression : Expression
    {
        /// <summary>Gets the static type of the expression that this <see cref="T:ExpressionMath.Expressions.Expression" /> represents.</summary>
        /// <returns>The <see cref="P:ExpressionMath.Expressions.UnaryExpression.Type" /> that represents the static type of the expression.</returns>
        public override sealed Type Type { get; }
        

        /// <summary>Returns the node type of this <see cref="T:ExpressionMath.Expressions.Expression" />.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> that represents this expression.</returns>
        public override sealed ExpressionType NodeType { get; }
        
        /// <summary>Gets the operand of the unary operation.</summary>
        /// <returns>An <see cref="T:ExpressionMath.Expressions.Expression" /> that represents the operand of the unary operation.</returns>
        public Expression Operand { get; }
        
        /// <summary>Gets the implementing method for the unary operation.</summary>
        /// <returns>The <see cref="T:System.Reflection.MethodInfo" /> that represents the implementing method.</returns>
        public MethodInfo Method { get; }
                
        internal UnaryExpression(ExpressionType nodeType, Expression expression, Type type, MethodInfo method)
        {
            Operand = expression;
            Method = method;
            NodeType = nodeType;
            Type = type;
        }

        protected internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitUnary(this);
        }

        /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
        /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
        /// <param name="operand">The <see cref="P:ExpressionMath.Expressions.UnaryExpression.Operand" /> property of the result.</param>
        public UnaryExpression Update(Expression operand)
        {
            if (operand == this.Operand)
                return this;

            return Expression.MakeUnary(this.NodeType, operand, this.Type, this.Method);
        }
    }
}
