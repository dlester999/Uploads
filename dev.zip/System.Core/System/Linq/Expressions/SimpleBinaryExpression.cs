﻿using System;

namespace ExpressionMath.Expressions
{
    internal class SimpleBinaryExpression : BinaryExpression
    {
        private readonly ExpressionType _nodeType;
        private readonly Type _type;

        public override sealed ExpressionType NodeType { get; }

        public override sealed Type Type { get; }

        internal SimpleBinaryExpression(ExpressionType nodeType, Expression left, Expression right, Type type)
          : base(left, right)
        {
            NodeType = nodeType;
            Type = type;
        }
    }
}
