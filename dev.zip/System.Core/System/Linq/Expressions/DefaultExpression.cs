﻿using System;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents the default value of a type or an empty expression.</summary>
    public sealed class DefaultExpression : Expression
    {
        /// <summary>Gets the static type of the expression that this <see cref="T:ExpressionMath.Expressions.Expression" /> represents.</summary>
        /// <returns>The <see cref="P:ExpressionMath.Expressions.DefaultExpression.Type" /> that represents the static type of the expression.</returns>
        public override sealed Type Type { get; }

        /// <summary>Returns the node type of this expression. Extension nodes should return <see cref="F:ExpressionMath.Expressions.ExpressionType.Extension" /> when overriding this method.</summary>
        /// <returns>The <see cref="T:ExpressionMath.Expressions.ExpressionType" /> of the expression.</returns>

        public override sealed ExpressionType NodeType => ExpressionType.Default;

        internal DefaultExpression(Type type)
        {
            Type = type;
        }

        protected internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitDefault(this);
        }
    }
}