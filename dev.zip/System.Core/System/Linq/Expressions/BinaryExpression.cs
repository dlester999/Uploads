﻿using System.Reflection;

namespace ExpressionMath.Expressions
{
    /// <summary>Represents an expression that has a binary operator.</summary>
    public class BinaryExpression : Expression
    {
        /// <summary>Gets the right operand of the binary operation.</summary>
        /// <returns>An <see cref="T:ExpressionMath.Expressions.Expression" /> that represents the right operand of the binary operation.</returns>
        public Expression Right { get; }

        /// <summary>Gets the left operand of the binary operation.</summary>
        /// <returns>An <see cref="T:ExpressionMath.Expressions.Expression" /> that represents the left operand of the binary operation.</returns>
        public Expression Left { get; }

        /// <summary>Gets the implementing method for the binary operation.</summary>
        /// <returns>The <see cref="T:System.Reflection.MethodInfo" /> that represents the implementing method.</returns>
        public MethodInfo Method => GetMethod();

        internal BinaryExpression(Expression left, Expression right)
        {
            Left = left;
            Right = right;
        }

        internal virtual MethodInfo GetMethod()
        {
            return (MethodInfo)null;
        }

        /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
        /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
        /// <param name="left">The <see cref="P:ExpressionMath.Expressions.BinaryExpression.Left" /> property of the result. </param>
        /// <param name="conversion">The <see cref="P:ExpressionMath.Expressions.BinaryExpression.Conversion" /> property of the result.</param>
        /// <param name="right">The <see cref="P:ExpressionMath.Expressions.BinaryExpression.Right" /> property of the result. </param>
        public BinaryExpression Update(Expression left, Expression right)
        {
            if (left == Left && right == Right)
                return this;

            return Expression.MakeBinary(this.NodeType, left, right, false, this.Method, null);
        }

        /// <summary>Dispatches to the specific visit method for this node type. For example, <see cref="T:ExpressionMath.Expressions.MethodCallExpression" /> calls the <see cref="M:ExpressionMath.Expressions.ExpressionVisitor.VisitMethodCall(ExpressionMath.Expressions.MethodCallExpression)" />.</summary>
        /// <returns>The result of visiting this node.</returns>
        /// <param name="visitor">The visitor to visit this node with.</param>
        protected internal override Expression Accept(ExpressionVisitor visitor)
        {
            return visitor.VisitBinary(this);
        }

        internal static Expression Create(ExpressionType nodeType, Expression left, Expression right, Type type, MethodInfo method, LambdaExpression conversion)
        {
            if (nodeType == ExpressionType.Assign)
                return (Expression)new AssignBinaryExpression(left, right);

            if (method != (MethodInfo)null)
                return (Expression)new MethodBinaryExpression(nodeType, left, right, type, method);

            if (type == typeof(bool))
                return (Expression)new LogicalBinaryExpression(nodeType, left, right);

            return (Expression)new SimpleBinaryExpression(nodeType, left, right, type);
        }
    }
}