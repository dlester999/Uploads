﻿using System;

namespace ExpressionMath.Expressions
{
  /// <summary>Represents a catch statement in a try block.</summary>
  public sealed class CatchBlock
  {
    private readonly Type _test;
    private readonly ParameterExpression _var;
    private readonly Expression _body;
    private readonly Expression _filter;

    /// <summary>Gets a reference to the <see cref="T:System.Exception" /> object caught by this handler.</summary>
    /// <returns>The <see cref="T:ExpressionMath.Expressions.ParameterExpression" /> object representing a reference to the <see cref="T:System.Exception" /> object caught by this handler.</returns>
    
    public ParameterExpression Variable
    {
       get
      {
        return this._var;
      }
    }

    /// <summary>Gets the type of <see cref="T:System.Exception" /> this handler catches.</summary>
    /// <returns>The <see cref="T:System.Type" /> object representing the type of <see cref="T:System.Exception" /> this handler catches.</returns>
    
    public Type Test
    {
       get
      {
        return this._test;
      }
    }

    /// <summary>Gets the body of the catch block.</summary>
    /// <returns>The <see cref="T:ExpressionMath.Expressions.Expression" /> object representing the catch body.</returns>
    
    public Expression Body
    {
       get
      {
        return this._body;
      }
    }

    /// <summary>Gets the body of the <see cref="T:ExpressionMath.Expressions.CatchBlock" /> filter.</summary>
    /// <returns>The <see cref="T:ExpressionMath.Expressions.Expression" /> object representing the body of the <see cref="T:ExpressionMath.Expressions.CatchBlock" /> filter.</returns>
    
    public Expression Filter
    {
       get
      {
        return this._filter;
      }
    }

    internal CatchBlock(Type test, ParameterExpression variable, Expression body, Expression filter)
    {
      this._test = test;
      this._var = variable;
      this._body = body;
      this._filter = filter;
    }

    /// <summary>Returns a <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.</summary>
    /// <returns>A <see cref="T:System.String" /> that represents the current <see cref="T:System.Object" />.</returns>
    
    public override string ToString()
    {
      return ExpressionStringBuilder.CatchBlockToString(this);
    }

    /// <summary>Creates a new expression that is like this one, but using the supplied children. If all of the children are the same, it will return this expression.</summary>
    /// <returns>This expression if no children are changed or an expression with the updated children.</returns>
    /// <param name="variable">The <see cref="P:ExpressionMath.Expressions.CatchBlock.Variable" /> property of the result.</param>
    /// <param name="filter">The <see cref="P:ExpressionMath.Expressions.CatchBlock.Filter" /> property of the result.</param>
    /// <param name="body">The <see cref="P:ExpressionMath.Expressions.CatchBlock.Body" /> property of the result.</param>
    
    public CatchBlock Update(ParameterExpression variable, Expression filter, Expression body)
    {
      if (variable == this.Variable && filter == this.Filter && body == this.Body)
        return this;
      return Expression.MakeCatchBlock(this.Test, variable, body, filter);
    }
  }
}
